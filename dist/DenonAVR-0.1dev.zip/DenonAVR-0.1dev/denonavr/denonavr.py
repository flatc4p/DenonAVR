class DenonAVR:
    def __init__(self, address, name):
        self.name = name
        self.address = address
        self.s = socket()

    def connect(self):
        s.connect