from denonavr import DenonAVR
from socket import socket