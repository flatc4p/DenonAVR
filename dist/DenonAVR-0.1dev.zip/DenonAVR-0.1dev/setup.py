from distutils.core import setup

setup(
    name='DenonAVR',
    version='0.1dev',
    packages=['denonavr', ],
    license='MIT',
    long_description=open('README.txt').read(),
)
